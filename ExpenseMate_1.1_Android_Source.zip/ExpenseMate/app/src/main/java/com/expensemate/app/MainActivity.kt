package com.expensemate.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.time.LocalDate
import java.util.Locale

private val Navy = Color(0xFF123B70)
private val Blue = Color(0xFF1769D2)
private val Cyan = Color(0xFF20B8C8)
private val Purple = Color(0xFF8064D8)
private val Green = Color(0xFF168B4B)
private val Red = Color(0xFFC63E4B)
private val Ink = Color(0xFF182638)
private val Muted = Color(0xFF6D7B8C)
private val Canvas = Color(0xFFF4F8FD)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dao = ExpenseDatabase.get(this).dao()
        lifecycleScope.launch {
            val prefs = getSharedPreferences("expensemate_settings", android.content.Context.MODE_PRIVATE)
            if (!prefs.getBoolean("v11_reset_done", false)) {
                dao.deleteAllGroups()
                prefs.edit().remove("last_group_id").putBoolean("v11_reset_done", true).apply()
            }
            setContent { ExpenseMateApp(dao) }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExpenseMateApp(dao: ExpenseDao) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("expensemate_settings", android.content.Context.MODE_PRIVATE) }
    val groups by dao.groups().collectAsStateWithLifecycle(initialValue = emptyList())
    var selectedGroupId by remember { mutableLongStateOf(prefs.getLong("last_group_id", 0L)) }
    LaunchedEffect(groups) {
        if (groups.isNotEmpty() && groups.none { it.id == selectedGroupId }) {
            selectedGroupId = groups.first().id
            prefs.edit().putLong("last_group_id", selectedGroupId).apply()
        }
    }
    LaunchedEffect(selectedGroupId) { if (selectedGroupId != 0L) prefs.edit().putLong("last_group_id", selectedGroupId).apply() }
    val selectedGroup = groups.firstOrNull { it.id == selectedGroupId }
    val members by dao.members(selectedGroupId).collectAsStateWithLifecycle(initialValue = emptyList())
    val expenses by dao.expenses(selectedGroupId).collectAsStateWithLifecycle(initialValue = emptyList())
    var tab by remember { mutableStateOf("Home") }
    var showAdd by remember { mutableStateOf(false) }
    var showGroupDialog by remember { mutableStateOf(false) }
    var showMemberDialog by remember { mutableStateOf(false) }
    var showRenameDialog by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Expense?>(null) }

    MaterialTheme(colorScheme = lightColorScheme(primary = Blue, secondary = Cyan, background = Canvas, surface = Color.White, onPrimary = Color.White, onBackground = Ink, onSurface = Ink)) {
        if (selectedGroup == null) {
            EmptyGroupsScreen(onCreate = { showGroupDialog = true })
        } else {
            Scaffold(
                containerColor = Canvas,
                topBar = {
                    TopAppBar(
                        title = { Column { Text("ExpenseMate", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 20.sp); Text(selectedGroup.name, color = Color.White.copy(alpha = .82f), fontSize = 11.sp) } },
                        colors = TopAppBarDefaults.topAppBarColors(containerColor = Navy),
                        actions = {
                            var expanded by remember { mutableStateOf(false) }
                            Box {
                                IconButton(onClick = { expanded = true }) { Icon(Icons.Default.ExpandMore, contentDescription = "Expense groups", tint = Color.White) }
                                DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                                    groups.forEach { g -> DropdownMenuItem(text = { Text(if (g.id == selectedGroupId) "✓ ${g.name}" else g.name) }, onClick = { selectedGroupId = g.id; tab = "Home"; expanded = false }) }
                                    Divider()
                                    DropdownMenuItem(text = { Text("+ Create expense group") }, onClick = { expanded = false; showGroupDialog = true })
                                    DropdownMenuItem(text = { Text("Rename current group") }, onClick = { expanded = false; showRenameDialog = true })
                                    DropdownMenuItem(text = { Text("Delete current group", color = Red) }, onClick = { expanded = false; showDeleteConfirm = true })
                                }
                            }
                        }
                    )
                },
                bottomBar = {
                    NavigationBar(containerColor = Color.White) {
                        listOf("Home", "Expenses", "Add", "Members", "Settle").forEach { item ->
                            NavigationBarItem(selected = tab == item, onClick = { if (item == "Add") showAdd = true else tab = item }, icon = { Icon(when(item) { "Home" -> Icons.Default.Dashboard; "Expenses" -> Icons.Default.ReceiptLong; "Add" -> Icons.Default.AddCircle; "Members" -> Icons.Default.People; else -> Icons.Default.AccountBalanceWallet }, contentDescription = item) }, label = { Text(item, fontSize = 10.sp) })
                        }
                    }
                },
                floatingActionButton = { if (tab == "Home" || tab == "Expenses") FloatingActionButton(onClick = { showAdd = true }, containerColor = Blue, contentColor = Color.White) { Icon(Icons.Default.Add, contentDescription = "Add expense") } }
            ) { padding ->
                when(tab) {
                    "Home" -> HomeScreen(Modifier.padding(padding), selectedGroup, members, expenses, onSettle = { tab = "Settle" }, onAddGroup = { showGroupDialog = true })
                    "Expenses" -> ExpenseListScreen(Modifier.padding(padding), expenses, members, onEdit = { editing = it }, onDelete = { e -> scope.launch { dao.deleteExpense(e) } })
                    "Members" -> MembersScreen(Modifier.padding(padding), members, expenses, onAdd = { showMemberDialog = true })
                    else -> SettlementScreen(Modifier.padding(padding), members, expenses)
                }
            }
        }
    }

    if (showAdd && selectedGroupId != 0L) ExpenseDialog(members, onDismiss = { showAdd = false }, onSave = { memberId, amount, date, category, note -> scope.launch { dao.addExpense(Expense(groupId = selectedGroupId, paidByMemberId = memberId, amount = amount, date = date, category = category, note = note)); showAdd = false } })
    editing?.let { current -> ExpenseDialog(members, current, onDismiss = { editing = null }, onSave = { memberId, amount, date, category, note -> scope.launch { dao.updateExpense(current.copy(paidByMemberId = memberId, amount = amount, date = date, category = category, note = note)); editing = null } }) }
    if (showGroupDialog) NameDialog("Create expense group", "Expense group name", onDismiss = { showGroupDialog = false }) { name -> scope.launch { selectedGroupId = dao.addGroup(ExpenseGroup(name = name)); tab = "Home"; showGroupDialog = false } }
    if (showRenameDialog && selectedGroup != null) NameDialog("Rename expense group", "New group name", onDismiss = { showRenameDialog = false }) { name -> scope.launch { dao.updateGroup(selectedGroup.copy(name = name)); showRenameDialog = false } }
    if (showDeleteConfirm && selectedGroup != null) AlertDialog(onDismissRequest = { showDeleteConfirm = false }, title = { Text("Delete expense group?") }, text = { Text("Delete \"${selectedGroup.name}\" and all its members and expenses? This cannot be undone.") }, confirmButton = { TextButton(onClick = { scope.launch { dao.deleteGroup(selectedGroup); showDeleteConfirm = false; tab = "Home" } }) { Text("Delete", color = Red) } }, dismissButton = { TextButton(onClick = { showDeleteConfirm = false }) { Text("Cancel") } })
    if (showMemberDialog && selectedGroupId != 0L) NameDialog("Add member", "Member name", onDismiss = { showMemberDialog = false }) { name -> scope.launch { dao.addMember(Member(groupId = selectedGroupId, name = name)); showMemberDialog = false } }
}

@Composable
fun EmptyGroupsScreen(onCreate: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFFEAF3FF), Color(0xFFF4EEFF), Color(0xFFE9FAF7)))), contentAlignment = Alignment.Center) {
        Column(Modifier.padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Box(Modifier.size(88.dp).background(Color.White, CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Default.Wallet, null, tint = Blue, modifier = Modifier.size(44.dp)) }
            Text("Welcome to ExpenseMate", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Navy)
            Text("Create your first expense group to start tracking shared expenses.", color = Muted)
            Button(onClick = onCreate, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("Create Expense Group") }
        }
    }
}

@Composable
fun HomeScreen(
    modifier: Modifier, group: ExpenseGroup?, members: List<Member>, expenses: List<Expense>,
    onSettle: () -> Unit, onAddGroup: () -> Unit
) {
    val total = expenses.sumOf { it.amount }
    val average = if (members.isNotEmpty()) total / members.size else 0.0
    val balances = members.map { m -> m to (expenses.filter { it.paidByMemberId == m.id }.sumOf { it.amount } - average) }
    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Column {
                    Text(group?.name ?: "Your group", color = Ink, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("${members.size} members • ${expenses.size} expenses", color = Muted, fontSize = 12.sp)
                }
                TextButton(onClick = onAddGroup) { Text("+ Group") }
            }
        }
        item {
            Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color.Transparent)) {
                Box(Modifier.background(Brush.linearGradient(listOf(Cyan, Blue, Color(0xFF4D65C8)))).fillMaxWidth().padding(20.dp)) {
                    Column {
                        Text("TOTAL GROUP EXPENSE", color = Color.White.copy(alpha = .9f), fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        Text(money(total), color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                        Text("Average per person: ${money(average)}", color = Color.White.copy(alpha = .92f), fontSize = 13.sp)
                    }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("Total entries", expenses.size.toString(), Modifier.weight(1f), Blue)
                StatCard("Members", members.size.toString(), Modifier.weight(1f), Purple)
            }
        }
        item { ExpensePieChart(expenses) }
        item { Text("Individual balances", fontWeight = FontWeight.Bold, fontSize = 17.sp, color = Ink) }
        items(balances) { (member, balance) ->
            Surface(shape = RoundedCornerShape(17.dp), color = Color.White, tonalElevation = 1.dp, modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(member.name)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(member.name, fontWeight = FontWeight.SemiBold)
                        Text("Paid ${money(expenses.filter { it.paidByMemberId == member.id }.sumOf { it.amount })}", color = Muted, fontSize = 12.sp)
                    }
                    BalancePill(balance)
                }
            }
        }
        item {
            Button(onClick = onSettle, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                Icon(Icons.Default.SwapHoriz, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("View settlement")
            }
        }
    }
}

@Composable
fun ExpensePieChart(expenses: List<Expense>) {
    val palette = listOf(Color(0xFF3979E8), Color(0xFF21A67A), Color(0xFFF1A33B), Color(0xFF9566D8), Color(0xFFE56B83), Color(0xFF20B8C8))
    val totals = expenses.groupBy { it.category }.mapValues { entry -> entry.value.sumOf { it.amount } }.toList().sortedByDescending { it.second }
    val total = totals.sumOf { it.second }
    Surface(color = Color.White, shape = RoundedCornerShape(20.dp), tonalElevation = 1.dp, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Expense breakdown", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Ink)
            if (total <= 0.0) Text("Add expenses to see the category pie chart.", color = Muted, fontSize = 12.sp)
            else Row(verticalAlignment = Alignment.CenterVertically) {
                Canvas(Modifier.size(142.dp)) {
                    var start = -90f
                    totals.forEachIndexed { index, item ->
                        val sweep = (item.second / total * 360.0).toFloat()
                        drawArc(color = palette[index % palette.size], startAngle = start, sweepAngle = sweep, useCenter = false, topLeft = androidx.compose.ui.geometry.Offset(8.dp.toPx(), 8.dp.toPx()), size = Size(size.width - 16.dp.toPx(), size.height - 16.dp.toPx()), style = Stroke(width = 23.dp.toPx(), cap = StrokeCap.Butt))
                        start += sweep
                    }
                }
                Spacer(Modifier.width(16.dp))
                Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                    totals.forEachIndexed { index, item ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(9.dp).background(palette[index % palette.size], CircleShape))
                            Spacer(Modifier.width(7.dp))
                            Column(Modifier.weight(1f)) { Text(item.first, fontSize = 12.sp, fontWeight = FontWeight.SemiBold); Text("${(item.second / total * 100).toInt()}% · ${money(item.second)}", fontSize = 10.sp, color = Muted) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StatCard(title: String, value: String, modifier: Modifier, tint: Color) {
    Surface(modifier, shape = RoundedCornerShape(16.dp), color = Color.White, tonalElevation = 1.dp) {
        Column(Modifier.padding(15.dp)) {
            Text(title, color = Muted, fontSize = 12.sp)
            Text(value, color = tint, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun MembersScreen(modifier: Modifier, members: List<Member>, expenses: List<Expense>, onAdd: () -> Unit) {
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Members (${members.size})", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Button(onClick = onAdd) { Icon(Icons.Default.PersonAdd, null); Text(" Add") }
        }
        Spacer(Modifier.height(12.dp))
        members.forEach { member ->
            val paid = expenses.filter { it.paidByMemberId == member.id }.sumOf { it.amount }
            Surface(color = Color.White, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth().padding(bottom = 9.dp)) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(member.name)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(member.name, fontWeight = FontWeight.SemiBold)
                        Text("Total paid ${money(paid)}", color = Muted, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun ExpenseListScreen(modifier: Modifier, expenses: List<Expense>, members: List<Member>, onEdit: (Expense) -> Unit, onDelete: (Expense) -> Unit) {
    var filter by remember { mutableStateOf("All") }
    val filtered = expenses.filter { filter == "All" || members.firstOrNull { m -> m.id == it.paidByMemberId }?.name == filter }
    Column(modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Spacer(Modifier.height(12.dp))
        Text("Expense history", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(vertical = 10.dp)) {
            listOf("All").plus(members.map { it.name }).forEach { name ->
                FilterChip(selected = filter == name, onClick = { filter = name }, label = { Text(name) })
            }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(filtered, key = { it.id }) { expense ->
                val payer = members.firstOrNull { it.id == expense.paidByMemberId }?.name ?: "Unknown"
                Surface(color = Color.White, shape = RoundedCornerShape(15.dp), modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(expense.category, fontWeight = FontWeight.SemiBold)
                            Text("$payer • ${expense.date}${if (expense.note.isNotBlank()) " • ${expense.note}" else ""}", color = Muted, fontSize = 11.sp)
                        }
                        Text(money(expense.amount), color = Navy, fontWeight = FontWeight.Bold)
                        IconButton(onClick = { onEdit(expense) }) { Icon(Icons.Default.Edit, "Edit", tint = Blue) }
                        IconButton(onClick = { onDelete(expense) }) { Icon(Icons.Default.DeleteOutline, "Delete", tint = Red) }
                    }
                }
            }
        }
    }
}

@Composable
fun SettlementScreen(modifier: Modifier, members: List<Member>, expenses: List<Expense>) {
    val total = expenses.sumOf { it.amount }
    val average = if (members.isNotEmpty()) total / members.size else 0.0
    val balances = members.map { m ->
        m to (expenses.filter { it.paidByMemberId == m.id }.sumOf { it.amount } - average)
    }
    val debtors = balances.filter { it.second < -0.005 }.map { it.first.name to -it.second }.toMutableList()
    val creditors = balances.filter { it.second > 0.005 }.map { it.first.name to it.second }.toMutableList()
    val transfers = mutableListOf<Triple<String, String, Double>>()
    var di = 0; var ci = 0
    while (di < debtors.size && ci < creditors.size) {
        val amount = minOf(debtors[di].second, creditors[ci].second)
        if (amount > 0.005) transfers.add(Triple(debtors[di].first, creditors[ci].first, amount))
        debtors[di] = debtors[di].first to (debtors[di].second - amount)
        creditors[ci] = creditors[ci].first to (creditors[ci].second - amount)
        if (debtors[di].second < 0.005) di++
        if (creditors[ci].second < 0.005) ci++
    }
    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Smart settlement", fontSize = 21.sp, fontWeight = FontWeight.Bold) }
        item {
            Surface(color = Color(0xFFEAF7EF), shape = RoundedCornerShape(16.dp)) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CheckCircle, null, tint = Green)
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("Suggested payments", fontWeight = FontWeight.Bold, color = Green)
                        Text("Settle the balances with as few transfers as possible.", fontSize = 12.sp, color = Muted)
                    }
                }
            }
        }
        items(transfers) { (from, to, amount) ->
            Surface(color = Color.White, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(from, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(8.dp))
                    Icon(Icons.Default.ArrowForward, null, tint = Blue)
                    Spacer(Modifier.width(8.dp))
                    Text(to, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text(money(amount), color = Green, fontWeight = FontWeight.Bold)
                }
            }
        }
        item { Text("Current difference from average", fontWeight = FontWeight.Bold, fontSize = 16.sp) }
        items(balances) { (member, balance) ->
            Row(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(14.dp)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(member.name, modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                BalancePill(balance)
            }
        }
        item { Text("Group total: ${money(total)}  •  Average: ${money(average)}", color = Muted, fontSize = 12.sp) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExpenseDialog(
    members: List<Member>, initial: Expense? = null, onDismiss: () -> Unit,
    onSave: (Long, Double, String, String, String) -> Unit
) {
    var memberId by remember(initial, members) { mutableLongStateOf(initial?.paidByMemberId ?: members.firstOrNull()?.id ?: 0L) }
    var amount by remember(initial) { mutableStateOf(initial?.amount?.toString() ?: "") }
    var date by remember(initial) { mutableStateOf(initial?.date ?: LocalDate.now().toString()) }
    var category by remember(initial) { mutableStateOf(initial?.category ?: "Food") }
    var note by remember(initial) { mutableStateOf(initial?.note ?: "") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Add expense" else "Edit expense", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Text("Who paid?", fontWeight = FontWeight.SemiBold)
                var expanded by remember { mutableStateOf(false) }
                ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                    OutlinedTextField(
                        value = members.firstOrNull { it.id == memberId }?.name ?: "Select member",
                        onValueChange = {}, readOnly = true, modifier = Modifier.menuAnchor().fillMaxWidth(),
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) }
                    )
                    ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        members.forEach { m -> DropdownMenuItem(text = { Text(m.name) }, onClick = { memberId = m.id; expanded = false }) }
                    }
                }
                OutlinedTextField(amount, { amount = it }, label = { Text("Amount (BDT)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
                OutlinedTextField(date, { date = it }, label = { Text("Date (YYYY-MM-DD)") }, modifier = Modifier.fillMaxWidth())
                var catExpanded by remember { mutableStateOf(false) }
                ExposedDropdownMenuBox(expanded = catExpanded, onExpandedChange = { catExpanded = !catExpanded }) {
                    OutlinedTextField(category, {}, readOnly = true, label = { Text("Category") }, modifier = Modifier.menuAnchor().fillMaxWidth(), trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(catExpanded) })
                    ExposedDropdownMenu(expanded = catExpanded, onDismissRequest = { catExpanded = false }) {
                        listOf("Food", "Transport", "Shopping", "Accommodation", "Bills", "Other").forEach { c ->
                            DropdownMenuItem(text = { Text(c) }, onClick = { category = c; catExpanded = false })
                        }
                    }
                }
                OutlinedTextField(note, { note = it }, label = { Text("Note (optional)") }, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            Button(
                enabled = amount.toDoubleOrNull()?.let { it > 0 } == true && memberId != 0L && runCatching { LocalDate.parse(date) }.isSuccess,
                onClick = { onSave(memberId, amount.toDouble(), date, category, note) }
            ) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun NameDialog(title: String, label: String, onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var value by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(value, { value = it }, label = { Text(label) }, singleLine = true) },
        confirmButton = { Button(enabled = value.isNotBlank(), onClick = { onSave(value.trim()) }) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun Avatar(name: String) {
    val colors = listOf(Blue, Purple, Color(0xFFE69B36), Cyan)
    val color = colors[(name.firstOrNull()?.code ?: 0) % colors.size]
    Box(Modifier.size(42.dp).background(color.copy(alpha = .13f), CircleShape), contentAlignment = Alignment.Center) {
        Text(name.take(1).uppercase(), color = color, fontWeight = FontWeight.Bold, fontSize = 17.sp)
    }
}

@Composable
fun BalancePill(balance: Double) {
    val positive = balance >= 0
    Surface(color = if (positive) Color(0xFFE4F5EA) else Color(0xFFFCE8EA), shape = RoundedCornerShape(30.dp)) {
        Text(
            (if (positive) "+" else "−") + money(kotlin.math.abs(balance)),
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            color = if (positive) Green else Red, fontWeight = FontWeight.Bold, fontSize = 12.sp
        )
    }
}

fun money(value: Double): String {
    val format = NumberFormat.getNumberInstance(Locale("en", "BD"))
    format.minimumFractionDigits = 2
    format.maximumFractionDigits = 2
    return "৳" + format.format(value)
}
