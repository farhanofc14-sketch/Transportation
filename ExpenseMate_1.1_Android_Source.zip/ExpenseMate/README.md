# ExpenseMate 1.1

Offline-first shared expense tracker for Android. Currency: BDT (৳).

## Version 1.1 updates
- No automatic Dhaka Trip or sample-member creation.
- One-time reset of existing expense groups when upgrading from v1.0, as requested. This deletes existing groups, members, and expenses.
- First launch shows an empty state with **Create Expense Group**.
- App remembers and opens the last-used expense group.
- Switch between groups from the top-bar group selector.
- Create, rename, and delete expense groups. Deletion asks for confirmation and removes that group's members and expenses.
- Colorful dashboard with a category expense pie chart.
- Existing expense entry/edit/delete, member, history, and settlement screens retained.

## Build
Open the project in Android Studio or use the included GitHub Actions workflow to build `:app:assembleDebug` with JDK 17 and Gradle 8.9.
