# Build ExpenseMate APK using only your Android phone

This project includes a GitHub Actions workflow at `.github/workflows/build-apk.yml`.
GitHub's cloud runner builds the APK; no computer or Android Studio is needed.

## Steps

1. Create or sign in to a GitHub account in Chrome on your phone.
2. Create a **public or private repository** named `ExpenseMate`.
3. Extract `ExpenseMate_Android_Source.zip` using your phone's Files app.
4. In the GitHub repository, use **Add file -> Upload files** and upload the project contents, including the hidden `.github` folder and its `workflows/build-apk.yml` file. Make sure `settings.gradle.kts`, `build.gradle.kts`, `gradle.properties`, `app/`, `README.md`, and `.github/` are at the repository root (not nested inside an extra ExpenseMate folder).
5. Commit the uploaded files to the `main` branch.
6. Open the repository's **Actions** tab. If prompted, enable GitHub Actions.
7. Select **Build ExpenseMate APK**, tap **Run workflow**, choose `main`, and run it.
8. Wait for the workflow to finish with a green check mark.
9. Open the completed workflow run, scroll to **Artifacts**, and download `ExpenseMate-debug-apk`.
10. Extract the downloaded artifact ZIP. Tap `app-debug.apk` to install it. If Android asks, allow Chrome or your Files app to install unknown apps, then retry the APK.

## Important

- The APK is a debug build for personal testing, not a Play Store release.
- Keep the GitHub repository private if you do not want the source code publicly visible.
- GitHub may require email verification and may display slightly different mobile menus.
- If the workflow fails, open the failed run and share the error log so it can be fixed.
