package com.expensemate.app

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "groups")
data class ExpenseGroup(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "members",
    foreignKeys = [ForeignKey(
        entity = ExpenseGroup::class,
        parentColumns = ["id"],
        childColumns = ["groupId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("groupId")]
)
data class Member(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val groupId: Long,
    val name: String
)

@Entity(
    tableName = "expenses",
    foreignKeys = [
        ForeignKey(entity = ExpenseGroup::class, parentColumns = ["id"], childColumns = ["groupId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = Member::class, parentColumns = ["id"], childColumns = ["paidByMemberId"], onDelete = ForeignKey.CASCADE)
    ],
    indices = [Index("groupId"), Index("paidByMemberId")]
)
data class Expense(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val groupId: Long,
    val paidByMemberId: Long,
    val amount: Double,
    val date: String,
    val category: String,
    val note: String
)

@Dao
interface ExpenseDao {
    @Query("SELECT * FROM `groups` ORDER BY createdAt DESC")
    fun groups(): Flow<List<ExpenseGroup>>

    @Query("SELECT * FROM members WHERE groupId = :groupId ORDER BY name")
    fun members(groupId: Long): Flow<List<Member>>

    @Query("SELECT * FROM expenses WHERE groupId = :groupId ORDER BY date DESC, id DESC")
    fun expenses(groupId: Long): Flow<List<Expense>>

    @Insert
    suspend fun addGroup(group: ExpenseGroup): Long

    @Insert
    suspend fun addMember(member: Member)

    @Insert
    suspend fun addExpense(expense: Expense)

    @Update
    suspend fun updateExpense(expense: Expense)

    @Delete
    suspend fun deleteExpense(expense: Expense)

    @Query("SELECT COUNT(*) FROM members WHERE groupId = :groupId")
    suspend fun memberCount(groupId: Long): Int

    @Query("SELECT COUNT(*) FROM `groups`")
    suspend fun groupCount(): Int
}

@Database(entities = [ExpenseGroup::class, Member::class, Expense::class], version = 1, exportSchema = false)
abstract class ExpenseDatabase : RoomDatabase() {
    abstract fun dao(): ExpenseDao

    companion object {
        @Volatile private var INSTANCE: ExpenseDatabase? = null
        fun get(context: Context): ExpenseDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    ExpenseDatabase::class.java,
                    "expensemate.db"
                ).build().also { INSTANCE = it }
            }
    }
}
