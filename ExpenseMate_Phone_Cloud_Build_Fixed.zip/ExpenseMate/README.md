# ExpenseMate Android App

Native Android starter app built with Kotlin, Jetpack Compose, and Room.

## Included
- Offline Room database
- Multiple expense groups
- Add members to the selected group
- Add, edit, and delete expense records
- Expense history with member filter
- Dashboard totals and per-member difference from average
- Suggested minimum-transfer settlement calculation
- BDT formatting

## Open in Android Studio
1. Unzip this project.
2. Open the `ExpenseMate` folder in Android Studio (Hedgehog or newer recommended).
3. Use JDK 17.
4. Allow Gradle sync to complete.
5. Run on an Android 8.0+ device or emulator.

## Notes
- First launch creates a sample `Dhaka Trip` group with Fahim, Farhan, and Rashed.
- All records are stored locally in `expensemate.db`.
- This is a functional starter implementation, not a signed production APK.
- Before release, add automated tests, backup/export, data validation, accessibility review, and a production app icon.
